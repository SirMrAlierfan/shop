
import "./App.css";


import Categories from "./components/PRODUCT/index";

function App() {

  return (
    <>
 
      <Categories />
     
    </>
  );
}

export default App;

