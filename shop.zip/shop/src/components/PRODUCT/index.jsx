import { useEffect, useState } from "react";

const Categories = () => {
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState("jewelery");
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [isProductsLoading, setIsProductsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch("https://fakestoreapi.com/products/categories")
      .then((res) => res.json())
      .then((data) => {
        setCategories(data);
      })
      .catch((error) => {
        setError("Failed to load categories");
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, []);

  useEffect(() => {
    if (selectedCategory) {
      setIsProductsLoading(true);
      fetch(`https://fakestoreapi.com/products/category/${selectedCategory}`)
        .then((res) => res.json())
        .then((data) => {
          setProducts(data);
          setFilteredProducts(data);
        })
        .catch((error) => {
          setError("Failed to load products");
        })
        .finally(() => {
          setIsProductsLoading(false);
        });
    }
  }, [selectedCategory]);

  useEffect(() => {
    const filtered = products.filter((product) =>
      product.title.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredProducts(filtered);
  }, [searchTerm, products]);

  const handleSelectCategory = (item) => {
    setSelectedCategory(item);
  };

  if (isLoading) {
    return <h1>Loading categories...</h1>;
  }

  return (
    <>
      <input
        type="search"
        placeholder="Search products"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      {error && <div style={{ color: "red" }}>{error}</div>}

      <h1>CATEGORIES</h1>

      {categories.map((category) => (
        <button onClick={() => handleSelectCategory(category)} key={category}>
          {category}
        </button>
      ))}

      <h2>{selectedCategory}</h2>

      <section>
        {isProductsLoading && <h6>Loading Products...</h6>}
        {!isProductsLoading && filteredProducts.length === 0 && (
          <h6>No products found</h6> 
        )}

        {!isProductsLoading &&
          filteredProducts.map((product) => {
            return (
              <div key={product.id}>
                <img src={product.image} width={200} alt={product.title} />
                <h3>{product.title}</h3>
                <p>{`$${product.price}`}</p>
              </div>
            );
          })}
      </section>
    </>
  );
};

export default Categories;
